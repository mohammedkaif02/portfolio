package com.example.safatech_static_web

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
