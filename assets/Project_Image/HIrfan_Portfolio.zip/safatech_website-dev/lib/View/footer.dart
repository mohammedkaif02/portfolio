import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:safatech_static_web/Controller/controller.dart';
import 'package:safatech_static_web/responsive.dart';
import 'package:safatech_static_web/themeColor.dart';
import 'package:url_launcher/url_launcher.dart';

class Footer extends StatelessWidget {
  Footer({super.key});
  final SafatechController safatechCtrl = Get.put(SafatechController());

  final List<String> socialMedia = [
    'instagram',
    'whatsapp',
    'facebook',
    'x',
    'linkedin',
  ];

  @override
  Widget build(BuildContext context) {
    return Responsive(
      mobile: Container(
        // height: 190,
        decoration: BoxDecoration(color: secondaryColor),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SvgPicture.asset(
                        'assets/icons/safatech_icon.svg',
                        height: 40,
                        width: 20,
                      ),
                      const SizedBox(width: 10),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            'SAFATECH',
                            style: TextStyle(
                              fontSize: 26,
                              fontFamily: 'SafatechFont',
                              color: primaryColor,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            'Integrated Solutions Pvt. Ltd.',
                            style: TextStyle(
                                fontSize: 9.5,
                                color: primaryColor,
                                fontFamily: 'SafatechFont',
                                fontWeight: FontWeight.bold),
                          )
                        ],
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 15,
                  ),
                  Container(
                    width: 380,
                    child: Text(
                      "We are here to help you in making your solutions beautiful and professional!",
                      style: TextStyle(fontSize: 20, color: primaryColor),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 15,
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    'Follow Us :',
                    style: TextStyle(
                        fontSize: 22,
                        color: primaryColor,
                        fontWeight: FontWeight.bold),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  _buildSocialRow(socialMedia.sublist(0, 5)),
                ],
              ),
              SizedBox(
                height: 20,
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    'Address',
                    style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        color: primaryColor),
                  ),
                  Text(
                    'No: 2, 2nd Floor, Rama Garden, Karuvadikuppam Main Road, Near New Clock tower, Muthiyalpet, Puducherry-605003',
                    style: TextStyle(fontSize: 18, color: primaryColor),
                    textAlign: TextAlign.center,
                    softWrap: true,
                  ),
                  SizedBox(
                    height: 30,
                  ),
                  Text(
                    "Copyright © 2024 SAFATECH-All Rights Reserved",
                    style: TextStyle(
                      fontSize: 16,
                    ),
                  ),
                ],
              )
            ],
          ),
        ),
      ),
      tablet: Container(
        height: 260,
        decoration: BoxDecoration(color: secondaryColor),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    height: 150,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SvgPicture.asset(
                              'assets/icons/safatech_icon.svg',
                              height: 40,
                              width: 20,
                            ),
                            const SizedBox(width: 10),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  'SAFATECH',
                                  style: TextStyle(
                                    fontSize: 26,
                                    fontFamily: 'SafatechFont',
                                    color: primaryColor,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Text(
                                  'Integrated Solutions Pvt. Ltd.',
                                  style: TextStyle(
                                      fontSize: 9.5,
                                      color: primaryColor,
                                      fontFamily: 'SafatechFont',
                                      fontWeight: FontWeight.bold),
                                )
                              ],
                            ),
                          ],
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Container(
                          width: 380,
                          child: Text(
                            "We are here to help you in making your solutions beautiful and professional!",
                            style: TextStyle(fontSize: 18, color: primaryColor),
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    width: 373,
                    height: 206,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Follow Us :',
                              style: TextStyle(
                                  fontSize: 22,
                                  color: primaryColor,
                                  fontWeight: FontWeight.bold),
                            ),
                            _buildSocialRow(socialMedia.sublist(0, 5)),
                          ],
                        ),
                        Spacer(),
                        Text(
                          'Address',
                          style: TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.bold,
                              color: primaryColor),
                        ),
                        Text(
                          'No: 2, 2nd Floor, Rama Garden, Karuvadikuppam Main Road, Near New Clock tower, Muthiyalpet, Puducherry-605003',
                          style: TextStyle(fontSize: 18, color: primaryColor),
                          // textAlign: TextAlign.center,
                          softWrap: true,
                        ),
                        SizedBox(
                          height: 15,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              Spacer(),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "Copyright © 2024 SAFATECH-All Rights Reserved",
                    style: TextStyle(
                      fontSize: 18,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
      desktop: Container(
        height: 220,
        decoration: BoxDecoration(color: secondaryColor),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Container(
                    height: 170,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            SvgPicture.asset(
                              'assets/icons/safatech_icon.svg',
                              height: 40,
                              width: 20,
                            ),
                            const SizedBox(width: 10),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  'SAFATECH',
                                  style: TextStyle(
                                    fontSize: 26,
                                    fontFamily: 'SafatechFont',
                                    color: primaryColor,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Text(
                                  'Integrated Solutions Pvt. Ltd.',
                                  style: TextStyle(
                                      fontSize: 9.5,
                                      color: primaryColor,
                                      fontFamily: 'SafatechFont',
                                      fontWeight: FontWeight.bold),
                                )
                              ],
                            ),
                          ],
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Container(
                          width: 400,
                          child: Text(
                            "We are here to help you in making your solutions beautiful and professional!",
                            style: TextStyle(fontSize: 18, color: primaryColor),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    width: 500,
                    height: 170,
                    // color: Colors.red,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // SizedBox(
                            //   height: 10,
                            // ),
                            Text(
                              'Follow Us :',
                              style: TextStyle(
                                  fontSize: 22,
                                  color: primaryColor,
                                  fontWeight: FontWeight.bold),
                            ),
                            _buildSocialRow(socialMedia.sublist(0, 5)),
                          ],
                        ),
                        Spacer(),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Address',
                              style: TextStyle(
                                  fontSize: 22,
                                  fontWeight: FontWeight.bold,
                                  color: primaryColor),
                            ),
                            SizedBox(
                              height: 5,
                            ),
                            Text(
                              'No: 2, 2nd Floor, Rama Garden, Karuvadikuppam Main Road, Near New Clock tower, Muthiyalpet, Puducherry - 605003',
                              style:
                                  TextStyle(fontSize: 18, color: primaryColor),
                              // textAlign: TextAlign.center,
                              softWrap: true,
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              Spacer(),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "Copyright © 2024 SAFATECH-All Rights Reserved",
                    style: TextStyle(
                      fontSize: 18,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

Widget _buildSocialRow(List<String> icons) {
  final Map<String, String> socialMediaLinks = {
    'instagram': 'https://www.instagram.com/safatech?igsh=MTc3MWk1dXMwZjAzZg==',
    'whatsapp': 'https://api.whatsapp.com/send?phone=96555595272',
    'facebook':
        'https://www.facebook.com/Kuwait-Amateur-Radio-Society-%D8%A7%D9%84%D8%AC%D9%85%D8%B9%D9%8A%D8%A9-%D8%A7%D9%84%D9%83%D9%88%D9%8A%D8%AA%D9%8A%D8%A9-%D9%84%D9%87%D9%88%D8%A7%D8%A9-%D8%A7%D9%84%D9%84%D8%A7%D8%B3%D9%84%D9%83%D9%8A-155394701195306/',
    'x': 'https://x.com/i/flow/login?redirect_after_login=%2FKARS_9K2RA',
    'linkedin':
        'https://www.linkedin.com/in/%D8%AC%D9%85%D8%B9%D9%8A%D8%A9-%D9%87%D9%88%D8%A7%D8%A9-%D8%A7%D9%84%D9%84%D8%A7%D8%B3%D9%84%D9%83%D9%8A-kars-401275b9/',
  };

  return Container(
    width: 250,
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: icons.map((icon) {
        return InkWell(
          onTap: () async {
            final url = socialMediaLinks[icon]!;
            if (await canLaunch(url)) {
              await launch(url);
            } else {
              throw 'Could not launch $url';
            }
          },
          child: SvgPicture.asset('assets/svg/$icon.svg', height: 28),
        );
      }).toList(),
    ),
  );
}
