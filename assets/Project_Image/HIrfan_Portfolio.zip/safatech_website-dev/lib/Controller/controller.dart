import 'dart:async';

import 'package:flutter/material.dart';
import 'package:get/get.dart';

class SafatechController extends GetxController {
  final PageController pageController = PageController();
  final ScrollController scrollController = ScrollController();
  Map<int, RxBool> hoverStates = {};
//---------------------desktop-----------------------
  final GlobalKey screen1Key = GlobalKey();
  final GlobalKey screen2Key = GlobalKey();
  final GlobalKey screen3Key = GlobalKey();
  final GlobalKey screen4Key = GlobalKey();
  final GlobalKey screen5Key = GlobalKey();
  //====================================================
  RxInt selectedIndex = 0.obs;
  RxBool isExpanded = false.obs;
  var isExpandedList = <bool>[].obs;
  RxBool isButtonVisible = false.obs;
  late Map<GlobalKey, double> scrollPositions;
  Timer? timer;
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

//================================================================
  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController phoneNumberController = TextEditingController();
  final TextEditingController subController = TextEditingController();
  final TextEditingController messageController = TextEditingController();

  final GlobalKey<FormState> contactformkey = GlobalKey<FormState>();
//================================================================
  @override
  void onInit() {
    super.onInit();
    scrollPositions = {
      screen1Key: 0, //home
      screen2Key: 1000.0, //about us
      screen3Key: 810.0 + 1000.0, //product
      screen4Key: 810.0 + 850.0 + 1000.0, //service
      screen5Key: 810.0 + 850.0 + 899.0 + 1000.0, //contact us
      /*screen1Key: 0, //home
      screen2Key: 1080.0, //about us
      screen3Key: 1080.0 + 1080.0, //product
      screen4Key: 1080.0 + 1080.0 + 1080.0, //service
      screen5Key: 1080.0 + 1080.0 + 1080.0 + 1080.0, //contact us*/
    };
    scrollController.addListener(scrollListener);
    //============================================================
  }

  void scrollListener() {
    double currentOffset = scrollController.offset;
    GlobalKey? activeKey;

    for (var entry in scrollPositions.entries) {
      double position = entry.value;
      if (currentOffset >= position) {
        activeKey = entry.key;
      } else {
        break;
      }
    }

    if (activeKey != null) {
      int newIndex = scrollPositions.keys.toList().indexOf(activeKey);
      if (newIndex != selectedIndex.value) {
        selectedIndex.value = newIndex;
      }
    }

    // Show/hide back-to-top button
    bool shouldShowButton = currentOffset > 100;
    if (shouldShowButton != isButtonVisible.value) {
      isButtonVisible.value = shouldShowButton;
    }
  }

  void scrollToPosition(double offset) {
    scrollController.animateTo(
      offset,
      duration: const Duration(seconds: 1),
      curve: Curves.easeInOut,
    );
  }

  void scrollToTop() {
    scrollController.animateTo(
      0,
      duration: const Duration(seconds: 1),
      curve: Curves.easeInOut,
    );
  }
}
//=============================controller 2====================

class ScrollControllerX extends GetxController {
  /*var selectedIndex = 0.obs; // Tracks selected navbar item
  var hoverIndex = (-1).obs; // Tracks hovered navbar item
  ScrollController scrollController = ScrollController();

  var selectedNavItem = "Home".obs; // Stores the selected item
  var hoverNavItem = "".obs; // Stores the hovered item

  final homeKey = GlobalKey();
  final aboutUsKey = GlobalKey();
  final whatIDoKey = GlobalKey();
  final portfolioKey = GlobalKey();
  final contactKey = GlobalKey();

  void scrollToSection(GlobalKey key, String item) {
    selectedNavItem.value = item; // Set the selected item
    Scrollable.ensureVisible(
      key.currentContext!,
      duration: Duration(milliseconds: 500),
      curve: Curves.easeInOut,
    );
  }*/
//=========================================================
  final ScrollController scrollController = ScrollController();

  RxString selectedNavItem = "Home".obs;
  RxString hoverNavItem = "".obs;

  // Define Global Keys for sections
  GlobalKey homeKey = GlobalKey();
  GlobalKey aboutUsKey = GlobalKey();
  GlobalKey whatIDoKey = GlobalKey();
  GlobalKey portfolioKey = GlobalKey();
  GlobalKey contactKey = GlobalKey();

  @override
  void onInit() {
    super.onInit();
    scrollController.addListener(_onScroll);
  }

  void _onScroll() {
    double offset = scrollController.offset;

    if (_isInView(homeKey)) {
      selectedNavItem.value = "Home";
    } else if (_isInView(aboutUsKey)) {
      selectedNavItem.value = "About";
    } else if (_isInView(whatIDoKey)) {
      selectedNavItem.value = "My Skill";
    } else if (_isInView(portfolioKey)) {
      selectedNavItem.value = "Portfolio";
    } else if (_isInView(contactKey)) {
      selectedNavItem.value = "Contact";
    }
  }

  bool _isInView(GlobalKey key) {
    final RenderBox? renderBox =
        key.currentContext?.findRenderObject() as RenderBox?;
    if (renderBox == null) return false;

    double position = renderBox.localToGlobal(Offset.zero).dy;
    return position >= 0 && position < 200; // Adjust threshold as needed
  }

  void scrollToSection(GlobalKey key, String section) {
    selectedNavItem.value = section;
    Scrollable.ensureVisible(
      key.currentContext!,
      duration: Duration(milliseconds: 500),
      curve: Curves.easeInOut,
    );
  }

  //=================flip==========
  var isFlipped = false.obs;

  void toggleRotation() {
    isFlipped.value = !isFlipped.value;
  }
}
