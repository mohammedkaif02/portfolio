import 'package:flutter/material.dart';

class Navbar extends StatelessWidget {
  final String text;
  final VoidCallback onTap;
  Navbar({super.key, required this.text, required this.onTap});

  var primeryColor = const Color(0xff0C3C55);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap, // Use the provided onTap callback
      child: Text(
        text,
        style: TextStyle(
            fontSize: 22, color: primeryColor, fontWeight: FontWeight.bold),
      ),
    );
  }
}
