import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:safatech_static_web/Controller/controller.dart';
import 'package:safatech_static_web/responsive.dart';
import 'package:safatech_static_web/themeColor.dart';

class ScrollToTop extends StatelessWidget {
  ScrollToTop({super.key});
  final SafatechController safatechCtrl = Get.put(SafatechController());
  @override
  Widget build(BuildContext context) {
    return Positioned(
      bottom: Responsive.isMobile(context) ? 40 : 150,
      right: Responsive.isMobile(context) ? 20 : 60,
      child: Obx(() {
        return Visibility(
          visible: safatechCtrl.isButtonVisible.value,
          child: InkWell(
            onTap: safatechCtrl.scrollToTop,
            child: Container(
              height: 40,
              width: 40,
              decoration: BoxDecoration(
                color: primaryColor,
                borderRadius: BorderRadius.circular(50),
              ),
              child: Icon(
                Icons.keyboard_arrow_up,
                size: 28,
                color: secondaryColor,
              ),
            ),
          ),
        );
      }),
    );
  }
}
