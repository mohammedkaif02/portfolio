class Services {
  String? img;
  String? text;

  Services({
    this.img,
    this.text,
  });
}

class Products {
  String? logo;
  String? projectname;
  String? subname;
  String? para;
  String? appicon;
  String? appicon2;
  String? text;

  Products({
    this.logo,
    this.projectname,
    this.subname,
    this.para,
    this.appicon,
    this.appicon2,
    this.text,
  });
}
