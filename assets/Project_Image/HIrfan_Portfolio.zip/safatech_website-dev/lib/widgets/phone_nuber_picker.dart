import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:intl_phone_field/countries.dart';
import 'package:intl_phone_field/intl_phone_field.dart';
import 'package:intl_phone_field/phone_number.dart';

class PhoneNuberPicker extends StatelessWidget {
  const PhoneNuberPicker(
      {super.key,
      this.height,
      this.suffixText,
      this.onCountryChanged,
      this.counterStyle,
      this.onChanged,
      this.controlller,
      this.focusNode,
      this.validator,
      this.errorText});

  final double? height;

  final String? suffixText;

  final TextStyle? counterStyle;

  final TextEditingController? controlller;

  final void Function(Country)? onCountryChanged;
  final void Function(PhoneNumber)? onChanged;
  final FutureOr<String?> Function(PhoneNumber?)? validator;
  final FocusNode? focusNode;
  final String? errorText;

  @override
  Widget build(BuildContext context) {
    var theme = context.theme;
    return SizedBox(
      // width: height ?? 300,
      child: IntlPhoneField(
        inputFormatters: [FilteringTextInputFormatter.digitsOnly],
        // focusNode: focusNode,
        // autovalidateMode: AutovalidateMode.onUserInteraction,
        validator: validator,
        controller: controlller,
        cursorColor: Colors.black,
        decoration: InputDecoration(
          errorText: errorText,
          // suffixText: suffixText,
          suffixStyle: TextStyle(
              color: theme.primaryColor,
              fontSize: 18,
              fontWeight: FontWeight.w500),
          //counterStyle: counterStyle,
          fillColor: Colors.transparent,
          focusedBorder: OutlineInputBorder(
              borderSide: BorderSide(color: Colors.grey.shade800)),
          filled: true,
          focusColor: Colors.white,
          hoverColor: Colors.transparent,
          floatingLabelStyle: TextStyle(color: Colors.black),
          labelText: 'Phone Number',
          iconColor: Colors.white,
          border: OutlineInputBorder(),
        ),
        initialCountryCode: 'IN',
        onChanged: onChanged,
        onCountryChanged: onCountryChanged,
        disableLengthCheck: true,
      ),
    );
  }
}
