import 'package:flutter/material.dart';

const Color primaryColor = Color(0xff00abf0);
// const Color primaryColor = Color(0xffE66500);
const Color secondaryColor = Color(0xff081b29);
// const Color secondaryColor = Color(0xff121212);
